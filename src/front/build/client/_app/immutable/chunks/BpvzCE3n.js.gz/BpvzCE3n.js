import{as as a}from"./BaMWEeME.js";a();
