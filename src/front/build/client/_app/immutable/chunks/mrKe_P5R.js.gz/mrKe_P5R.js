import{as as a}from"./mo2ikcES.js";a();
