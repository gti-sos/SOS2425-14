import{au as a}from"./ZYZYCwXw.js";a();
