import{as as a}from"./B9KnJm2w.js";a();
