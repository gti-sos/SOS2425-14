import{ap as a}from"./BGtGGxyh.js";a();
