import{i as a}from"./D2QEyh5V.js";a();
