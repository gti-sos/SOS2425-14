import{S as a}from"./DvUjY8h5.js";a();
