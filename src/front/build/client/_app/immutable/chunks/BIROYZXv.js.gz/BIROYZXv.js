import{as as a}from"./CpQaROA0.js";a();
