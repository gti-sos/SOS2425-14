import{as as a}from"./cdyx5pLP.js";a();
