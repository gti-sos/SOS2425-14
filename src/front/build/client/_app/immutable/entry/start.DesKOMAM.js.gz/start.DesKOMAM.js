import{l as o,a as r}from"../chunks/BSc2Qz-A.js";export{o as load_css,r as start};
