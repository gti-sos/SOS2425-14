import{l as o,a as r}from"../chunks/CBd0k46R.js";export{o as load_css,r as start};
