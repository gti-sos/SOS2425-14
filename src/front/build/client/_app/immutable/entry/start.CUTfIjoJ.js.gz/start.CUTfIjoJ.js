import{l as o,a as r}from"../chunks/a4wE99Zp.js";export{o as load_css,r as start};
