import{l as o,a as r}from"../chunks/DIK3C3aQ.js";export{o as load_css,r as start};
