import{l as o,a as r}from"../chunks/DV9dEzUr.js";export{o as load_css,r as start};
