import{l as o,a as r}from"../chunks/DUTV1AL5.js";export{o as load_css,r as start};
