import{l as o,a as r}from"../chunks/9_0LQjj_.js";export{o as load_css,r as start};
